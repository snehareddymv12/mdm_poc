import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Box, Button, Typography, IconButton, Dialog, DialogTitle, DialogContent, TextField } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate } from 'react-router-dom';
 
const Upload = ({ open, handleClose, labelName, description, handleUploadSubmit }) => {
  const navi = useNavigate();
   function handleUploadSubmit(){
       navi('/standard');
   }

  const onDrop = useCallback((acceptedFiles) => {
    console.log(acceptedFiles);
  }, []);
 
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: '.csv',
  });

  
 
  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <b>Upload File</b>
        <IconButton aria-label="close" onClick={handleClose} sx={{ position: 'absolute', right: 8, top: 8 }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Typography variant="subtitle1" align="left">Label Name</Typography>
        <TextField
          variant="outlined"
          fullWidth
          value={labelName}  // Reflect labelName here
          sx={{ marginBottom: 2 }}
          disabled  // Make it read-only
        />
       
        <Typography variant="subtitle1" align="left">Description</Typography>
        <TextField
          variant="outlined"
          fullWidth
          value={description}  // Reflect description here
          sx={{ marginBottom: 3 }}
          disabled  // Make it read-only
        />
 
        <Box
          {...getRootProps()}
          sx={{
            border: '2px dashed #183B66',
            borderRadius: '5px',
            padding: '20px',
            textAlign: 'center',
            cursor: 'pointer',
            backgroundColor: isDragActive ? '#f0f0f0' : '#fafafa',
          }}
        >
          <input {...getInputProps()} />
          {isDragActive ? (
            <p>Drop the files here ...</p>
          ) : (
            <p>Drag 'n' drop a file here, or click to select a file</p>
          )}
          <CloudUploadIcon fontSize="large" color="action" />
        </Box>
 
        <Button variant="contained" color="primary" onClick={handleUploadSubmit} sx={{ marginTop: 3 }}>
          Upload File
        </Button>
      </DialogContent>
    </Dialog>
  );
};
 
export default Upload;