import React, { useState } from "react";
import {
  Box,
  Typography,
  Checkbox,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import "../style/datatable.css";
import Datacleanpopup from "./Datacleanpopup";
import Navbar from '../pages/NavBar';


const Standardization = () => {
  const [rows, setRows] = useState([
    { id: 1, name: "Table 1", dataType: "String", standardization: "Uppercase" },
    { id: 2, name: "Table 2", dataType: "Integer", standardization: "Round" },
    { id: 3, name: "Table 3", dataType: "Date", standardization: "MM/DD/YYYY" },
    { id: 4, name: "Table 4", dataType: "Boolean", standardization: "True/False" },
    { id: 5, name: "Table 5", dataType: "Float", standardization: "Two decimal places" }
  ]); // Sample data

  const [show, setshow] = useState(false);
  const [popupdata, setpopupdata] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]); // State to store selected row IDs

  const handleCheckboxChange = (id) => {
    setSelectedRows((prevSelected) => {
      if (prevSelected.includes(id)) {
        return prevSelected.filter((rowId) => rowId !== id); // Deselect
      } else {
        return [...prevSelected, id]; // Select
      }
    });
  };

  const handleFinish = () => {
    const filteredData = rows.filter((row) => selectedRows.includes(row.id));
    setpopupdata(filteredData); // Set only selected rows data to popup
    setshow(true); // Show popup
  };

  const handleDeleteRows = (rowsToDelete) => {
    // Filter out rows that are in rowsToDelete
    const remainingPopupData = popupdata.filter(
      (row) => !rowsToDelete.includes(row.id)
    );
    setpopupdata(remainingPopupData);
    setSelectedRows(selectedRows.filter(id => !rowsToDelete.includes(id)));

    // Also delete from the main rows array
    const remainingRows = rows.filter((row) => !rowsToDelete.includes(row.id));
    setRows(remainingRows); // Update main rows state
  };

  return (
    <>
     <div style={{ display: 'flex' }}>
      <Navbar/>
      
      <div style={{flex: 1, marginTop: "4rem", marginLeft: "7rem" }}>
        <h1 style={{ color: "black", fontWeight: "inherit" }}>
          Choose the tables you want to sync
        </h1>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height: "64px",
            width: "100%",
            backgroundColor: "#f7f9fc",
            border: "1px solid #d1d5db",
          }}
        >
          <Typography
            sx={{
              color: "#374151",
              fontWeight: 700,
              letterSpacing: "0.05em",
              fontSize: "16px",
            }}
          >
            TABLENAME
          </Typography>
        </Box>

        <div className="data-table-container">
          {rows.map((row, index) => (
            <Box key={index} className="data-row">
              <Checkbox
                className="data-checkbox"
                checked={selectedRows.includes(row.id)} // Checkbox state
                onChange={() => handleCheckboxChange(row.id)} // Handle checkbox change
              />
              <Typography
                className="column-name"
                sx={{
                  fontWeight: "bold",
                  fontSize: "16px",
                  marginLeft: "30px",
                  marginRight: "28rem",
                }}
              >
                {row.name}
              </Typography>

              {/* DataType Accordion */}
              <Accordion
                style={{
                  width: "24%",
                  marginRight: "10rem",
                  backgroundColor: "#C8C3C3",
                }}
                className="accordion"
              >
                <AccordionSummary
                  expandIcon={<KeyboardArrowDownIcon />}
                  aria-controls={`panel1-content-${index}`} // Unique ID for accessibility
                  id={`panel1-header-${index}`} // Unique ID for accessibility
                >
                  <Typography>{row.dataType}</Typography>
                </AccordionSummary>
                <AccordionDetails></AccordionDetails>
              </Accordion>

              {/* Standardization Accordion */}
              <Accordion
                style={{
                  width: "30%",
                  marginRight: "16px",
                  backgroundColor: "#C8C3C3",
                }}
                className="accordion"
              >
                <AccordionSummary
                  expandIcon={<KeyboardArrowDownIcon />}
                  aria-controls={`panel2-content-${index}`} // Unique ID for accessibility
                  id={`panel2-header-${index}`} // Unique ID for accessibility
                >
                  <Typography>{row.standardization}</Typography>
                </AccordionSummary>
                <AccordionDetails></AccordionDetails>
              </Accordion>
            </Box>
          ))}
        </div>
        <hr style={{ marginTop: "7rem", backgroundColor: " #d1d5db" }} />
        <div
          style={{
            marginTop: "3px",
            display: "flex",
            gap: "6px",
            flexDirection: "row",
          }}
        >
          <Checkbox className="data-checkbox" />
          <Typography
            sx={{
              color: "gray",
              fontFamily: "inherit",
              marginTop: "5px",
              fontWeight: "bold",
              fontSize: "21px",
            }}
          >
            Are you sure you want to drop all null rows?
          </Typography>
        </div>
        <div
          style={{
            backgroundColor: "blue",
            color: "white",
            width: "14%",
            padding: "10px",
            marginTop: "16px",
            marginLeft: "15px",
            textAlign: "center",
            cursor: "pointer",
          }}
          onClick={handleFinish}
        >
          Finish
        </div>
      </div>
      {show && <div className="overlay" />}
      {/* Popup Component */}
      {show && (
        <Datacleanpopup
          setshow={setshow}
          popupdata={popupdata}
          handleDeleteRows={handleDeleteRows}
           // Pass delete function to popup
        />
      )}
      </div>
    </>
  );
};

export default Standardization;
