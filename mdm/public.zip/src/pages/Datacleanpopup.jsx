import React, { useState } from 'react';
import Button from '@mui/material/Button';
import { Box, Typography, Checkbox } from "@mui/material";

export default function Datacleanpopup({ setshow, popupdata, handleDeleteRows }) {
    const [data, setdata] = useState(popupdata);
    const [selectedRows, setSelectedRows] = useState([]);

    const handleCheckboxChange = (id) => {
        setSelectedRows((prevSelected) => {
          if (prevSelected.includes(id)) {
            return prevSelected.filter((rowId) => rowId !== id); // Deselect
          } else {
            return [...prevSelected, id]; // Select
          }
        });
    };

    const handleDelete = () => {
        // Call the parent component's function to delete the selected rows
        handleDeleteRows(selectedRows);
        setshow(false); // Close the popup
    };

    return (
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", marginTop: "110px", position: "absolute", top: "100px", left: "500px", backgroundColor: "white" }}>
            <div style={{ padding: "25px", width: "796px", minHeight: "432px" }}>
                <h2>Entity Details</h2>
                {data &&
                    data.map((e) => (
                        <div key={e.id}>
                            <p style={{ borderTop: "1px solid grey", opacity: "0.5" }}></p>
                            <div style={{display:"flex"}}>
                            <Checkbox
                                className="data-checkbox"
                                checked={selectedRows.includes(e.id)} // Checkbox state
                                onChange={() => handleCheckboxChange(e.id)} // Handle checkbox change
                            />
                            <p style={{ color: "grey", fontSize: "20px", padding: "10px" }}>{e.id},{e.name},{e.dataType},{e.standardization}</p>
                        </div>
                        </div>
                    ))
                }
                <div style={{ display: "flex", justifyContent: "space-between",marginTop:"15px" }}>
                    <Button variant="outlined" style={{ width: "178px", height: "48px" }} onClick={() => setshow(false)}>Go Back</Button>
                    <Button variant="contained" style={{ width: "178px", height: "48px" }} onClick={handleDelete}>Finish</Button>
                </div>
            </div>
        </div>
    );
}
